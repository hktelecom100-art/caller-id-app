import 'dart:convert';

import 'package:http/http.dart' as http;

import 'config.dart';

class NumberInfo {
  final String? name;
  final int spamCount;
  const NumberInfo(this.name, this.spamCount);
}

class SpamEntry {
  final String number;
  final String? name;
  final int count;
  const SpamEntry(this.number, this.name, this.count);
}

class Api {
  /// Last 10 digits only, so +8801935961077 and 01935961077 match.
  static String norm(String n) {
    final d = n.replaceAll(RegExp(r'[^0-9]'), '');
    return d.length > 10 ? d.substring(d.length - 10) : d;
  }

  static Map<String, String> get _headers => {
        'apikey': AppConfig.anonKey,
        if (AppConfig.anonKey.startsWith('eyJ'))
          'Authorization': 'Bearer ${AppConfig.anonKey}',
        'Content-Type': 'application/json',
      };

  static Uri _u(String path, [Map<String, String>? q]) =>
      Uri.parse('${AppConfig.url}/rest/v1/$path').replace(queryParameters: q);

  /// null = server not set up or request failed.
  /// NumberInfo(null, 0) = number not in the database.
  static Future<NumberInfo?> lookup(String number) async {
    if (!AppConfig.isSet) return null;
    try {
      final r = await http
          .get(
              _u('numbers', {
                'number': 'eq.${norm(number)}',
                'select': 'name,spam_count',
              }),
              headers: _headers)
          .timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final list = jsonDecode(r.body) as List;
      if (list.isEmpty) return const NumberInfo(null, 0);
      final o = list.first as Map<String, dynamic>;
      return NumberInfo(o['name'] as String?, (o['spam_count'] as num?)?.toInt() ?? 0);
    } catch (_) {
      return null;
    }
  }

  static Future<List<SpamEntry>?> topSpam() async {
    if (!AppConfig.isSet) return null;
    try {
      final r = await http
          .get(
              _u('numbers', {
                'spam_count': 'gte.1',
                'select': 'number,name,spam_count',
                'order': 'spam_count.desc',
                'limit': '50',
              }),
              headers: _headers)
          .timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final list = jsonDecode(r.body) as List;
      return [
        for (final o in list)
          SpamEntry(o['number'] as String, o['name'] as String?,
              (o['spam_count'] as num).toInt())
      ];
    } catch (_) {
      return null;
    }
  }

  static Future<bool> _rpc(String fn, Map<String, String> body) async {
    if (!AppConfig.isSet) return false;
    try {
      final r = await http
          .post(_u('rpc/$fn'), headers: _headers, body: jsonEncode(body))
          .timeout(const Duration(seconds: 8));
      return r.statusCode == 200 || r.statusCode == 204;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> reportSpam(String number) =>
      _rpc('report_spam', {'p_number': norm(number)});

  static Future<bool> suggestName(String number, String name) =>
      _rpc('suggest_name', {'p_number': norm(number), 'p_name': name});
}
