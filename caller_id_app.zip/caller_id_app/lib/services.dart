import 'package:call_log/call_log.dart' as cl;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

enum CallType { incoming, outgoing, missed }

class LogEntry {
  final String name, number, time;
  final CallType type;
  const LogEntry(this.name, this.number, this.time, this.type);
}

class Person {
  final String name, number;
  const Person(this.name, this.number);
}

class PhoneService {
  static Future<bool> requestPermissions() async {
    final r = await [Permission.phone, Permission.contacts].request();
    return (r[Permission.phone]?.isGranted ?? false) &&
        (r[Permission.contacts]?.isGranted ?? false);
  }

  static String _fmtTime(int? ms) {
    if (ms == null) return '';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    final now = DateTime.now();
    final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final m = d.minute.toString().padLeft(2, '0');
    final ap = d.hour >= 12 ? 'PM' : 'AM';
    final t = '$h:$m $ap';
    if (d.year == now.year && d.month == now.month && d.day == now.day) {
      return t;
    }
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    if (now.difference(d).inDays < 7) return '${days[d.weekday - 1]}, $t';
    return '${d.day}/${d.month}/${d.year}, $t';
  }

  static Future<List<LogEntry>> loadLogs() async {
    final entries = await cl.CallLog.get();
    return entries.take(150).map((e) {
      final number = e.number ?? '';
      final name = (e.name != null && e.name!.isNotEmpty) ? e.name! : number;
      CallType t;
      switch (e.callType) {
        case cl.CallType.outgoing:
          t = CallType.outgoing;
          break;
        case cl.CallType.missed:
        case cl.CallType.rejected:
        case cl.CallType.blocked:
          t = CallType.missed;
          break;
        default:
          t = CallType.incoming;
      }
      return LogEntry(name, number, _fmtTime(e.timestamp), t);
    }).toList();
  }

  static Future<List<Person>> loadContacts() async {
    final list = await FlutterContacts.getContacts(withProperties: true);
    final out = <Person>[];
    for (final c in list) {
      if (c.phones.isEmpty) continue;
      out.add(Person(c.displayName, c.phones.first.number));
    }
    out.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return out;
  }

  /// Opens the phone dialer with the number filled in.
  static Future<void> call(String number) async {
    await launchUrl(Uri(scheme: 'tel', path: number));
  }
}
