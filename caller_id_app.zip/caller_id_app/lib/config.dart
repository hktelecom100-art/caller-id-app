// This file is regenerated during the build from config.json (repo root).
class AppConfig {
  static const url = '';
  static const anonKey = '';
  static bool get isSet => url.isNotEmpty && anonKey.isNotEmpty;
}
