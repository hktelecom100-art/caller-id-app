import 'package:flutter/material.dart';

import 'package:permission_handler/permission_handler.dart';

import 'services.dart';

void main() => runApp(const CallerIdApp());

const kBlue = Color(0xFF0095FF);
const kDark = Color(0xFF3B4357);
const kSoft = Color(0xFFE8ECF5);

class CallerIdApp extends StatelessWidget {
  const CallerIdApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Caller ID',
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: kBlue,
          scaffoldBackgroundColor: const Color(0xFFF6F6F8),
        ),
        home: const RootPage(),
      );
}

// ---------------- Dummy data ----------------
// number -> [name, isSpam]
const numberDb = {
  '01935961077': ['Rafiq (Bike Showroom)', false],
  '01711223344': ['Loan Offer – Spam', true],
  '01811000000': ['Delivery Man', false],
};

// ---------------- Root ----------------
class RootPage extends StatefulWidget {
  const RootPage({super.key});
  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  int index = 0;
  final pages = const [HomePage(), SmsPage(), SpamPage(), IdPage()];

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: IndexedStack(index: index, children: pages)),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) {
            if (i == 4) {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const PremiumPage()));
            } else {
              setState(() => index = i);
            }
          },
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.sms_outlined), label: 'SMS'),
            NavigationDestination(
                icon: Icon(Icons.gpp_maybe_outlined), label: 'Spam'),
            NavigationDestination(
                icon: Icon(Icons.manage_search), label: 'ID'),
            NavigationDestination(
                icon: Icon(Icons.workspace_premium_outlined), label: 'Premium'),
          ],
        ),
      );
}

// ---------------- Home ----------------
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool missedOnly = false, loading = true, granted = false;
  String query = '';
  List<LogEntry> logs = [];
  List<Person> people = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    final ok = await PhoneService.requestPermissions();
    List<LogEntry> l = [];
    List<Person> p = [];
    if (ok) {
      l = await PhoneService.loadLogs();
      p = await PhoneService.loadContacts();
    }
    if (!mounted) return;
    setState(() {
      granted = ok;
      logs = l;
      people = p;
      loading = false;
    });
  }

  // Favorites = most frequently called numbers
  List<Person> get favorites {
    final count = <String, int>{};
    final names = <String, String>{};
    for (final l in logs) {
      if (l.number.isEmpty) continue;
      count[l.number] = (count[l.number] ?? 0) + 1;
      names[l.number] = l.name;
    }
    final keys = count.keys.toList()
      ..sort((a, b) => count[b]!.compareTo(count[a]!));
    return keys.take(5).map((k) => Person(names[k]!, k)).toList();
  }

  bool _match(String name, String number) {
    if (query.isEmpty) return true;
    final q = query.toLowerCase();
    return name.toLowerCase().contains(q) || number.contains(q);
  }

  void _openDialpad() {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) {
          final keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'];
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(ctrl.text.isEmpty ? 'Enter number' : ctrl.text,
                  style: const TextStyle(fontSize: 28)),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                childAspectRatio: 1.8,
                children: [
                  for (final k in keys)
                    TextButton(
                      onPressed: () => set(() => ctrl.text += k),
                      child: Text(k,
                          style: const TextStyle(fontSize: 26, color: kDark)),
                    ),
                ],
              ),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                IconButton(
                    onPressed: () => set(() {
                          if (ctrl.text.isNotEmpty) {
                            ctrl.text =
                                ctrl.text.substring(0, ctrl.text.length - 1);
                          }
                        }),
                    icon: const Icon(Icons.backspace_outlined)),
                FloatingActionButton(
                  backgroundColor: Colors.green,
                  onPressed: () {
                    Navigator.pop(ctx);
                    if (ctrl.text.isNotEmpty) PhoneService.call(ctrl.text);
                  },
                  child: const Icon(Icons.call, color: Colors.white),
                ),
              ]),
            ]),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Stack(children: [
        Column(children: [
          if (!granted && !loading)
            Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: kSoft, borderRadius: BorderRadius.circular(18)),
              child: Row(children: [
                const Expanded(
                  child: Text(
                      'Allow Phone and Contacts permission to see your call history and contacts.'),
                ),
                const SizedBox(width: 8),
                FilledButton(
                    onPressed: () async {
                      if (await Permission.phone.isPermanentlyDenied ||
                          await Permission.contacts.isPermanentlyDenied) {
                        await openAppSettings();
                      } else {
                        _load();
                      }
                    },
                    child: const Text('Allow')),
              ]),
            ),
          // search row
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Row(children: [
              Expanded(
                child: TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: InputDecoration(
                    hintText: 'Lookup numbers, search contacts',
                    suffixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none),
                  ),
                ),
              ),
              IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
              IconButton(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const MenuPage())),
                  icon: const Icon(Icons.settings_outlined)),
            ]),
          ),
          const TabBar(tabs: [
            Tab(text: 'History'),
            Tab(text: 'Contacts'),
            Tab(text: 'Favorites'),
          ]),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : TabBarView(children: [
                    _history(),
                    _people(people.where((p) => _match(p.name, p.number)).toList()),
                    _people(favorites.where((p) => _match(p.name, p.number)).toList()),
                  ]),
          ),
        ]),
        Positioned(
          right: 20,
          bottom: 16,
          child: FloatingActionButton(
            backgroundColor: kBlue,
            onPressed: _openDialpad,
            child: const Icon(Icons.dialpad, color: Colors.white),
          ),
        ),
      ]),
    );
  }

  Widget _history() {
    final list = logs
        .where((l) =>
            (!missedOnly || l.type == CallType.missed) && _match(l.name, l.number))
        .toList();
    return Column(children: [
      Row(children: [
        const SizedBox(width: 12),
        ChoiceChip(
            label: const Text('All'),
            selected: !missedOnly,
            onSelected: (_) => setState(() => missedOnly = false)),
        const SizedBox(width: 8),
        ChoiceChip(
            label: const Text('Missed Calls'),
            selected: missedOnly,
            onSelected: (_) => setState(() => missedOnly = true)),
      ]),
      Expanded(
        child: list.isEmpty
            ? const Center(child: Text('No calls to show'))
            : ListView.separated(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final l = list[i];
                  final icon = {
                    CallType.incoming: Icons.call_received,
                    CallType.outgoing: Icons.call_made,
                    CallType.missed: Icons.call_missed,
                  }[l.type]!;
                  return ListTile(
                    leading: const CircleAvatar(
                        backgroundColor: kSoft,
                        child: Icon(Icons.person, color: Colors.grey)),
                    title: Text(l.name),
                    subtitle: Row(children: [
                      Icon(icon,
                          size: 16,
                          color: l.type == CallType.missed
                              ? Colors.red
                              : Colors.grey),
                      const SizedBox(width: 6),
                      Text(l.time),
                    ]),
                    trailing: IconButton(
                        icon: const Icon(Icons.call, color: kBlue),
                        onPressed: () => PhoneService.call(l.number)),
                    onTap: () => PhoneService.call(l.number),
                  );
                },
              ),
      ),
    ]);
  }

  Widget _people(List<Person> items) => items.isEmpty
      ? const Center(child: Text('Nothing to show'))
      : ListView.builder(
          padding: const EdgeInsets.only(bottom: 90),
          itemCount: items.length,
          itemBuilder: (_, i) => ListTile(
            leading: const CircleAvatar(
                backgroundColor: kSoft,
                child: Icon(Icons.person, color: Colors.grey)),
            title: Text(items[i].name),
            subtitle: Text(items[i].number),
            trailing: IconButton(
                icon: const Icon(Icons.call, color: kBlue),
                onPressed: () => PhoneService.call(items[i].number)),
          ),
        );
}

// ---------------- SMS / Spam / ID ----------------
class SmsPage extends StatelessWidget {
  const SmsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: const [
        ListTile(title: Text('Messages', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        ListTile(
            leading: CircleAvatar(child: Icon(Icons.sms)),
            title: Text('Grameenphone'),
            subtitle: Text('Your data pack will expire soon...')),
        ListTile(
            leading: CircleAvatar(child: Icon(Icons.sms)),
            title: Text('bKash'),
            subtitle: Text('You have received Tk 500')),
      ]);
}

class SpamPage extends StatelessWidget {
  const SpamPage({super.key});
  @override
  Widget build(BuildContext context) {
    final spam = numberDb.entries.where((e) => e.value[1] == true);
    return ListView(children: [
      const ListTile(
          title: Text('Spam & Block list',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      for (final e in spam)
        ListTile(
          leading: const CircleAvatar(
              backgroundColor: Color(0xFFFFE5E5),
              child: Icon(Icons.block, color: Colors.red)),
          title: Text(e.key),
          subtitle: Text(e.value[0] as String),
        ),
    ]);
  }
}

class IdPage extends StatefulWidget {
  const IdPage({super.key});
  @override
  State<IdPage> createState() => _IdPageState();
}

class _IdPageState extends State<IdPage> {
  final ctrl = TextEditingController();
  String? result;
  bool spam = false;

  void lookup() {
    final n = ctrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    final r = numberDb[n];
    setState(() {
      result = r == null ? 'No info found for this number' : r[0] as String;
      spam = r != null && r[1] == true;
    });
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Lookup number',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(
            controller: ctrl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
                hintText: '01XXXXXXXXX', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: lookup, child: const Text('Search')),
          const SizedBox(height: 20),
          if (result != null)
            Card(
              child: ListTile(
                leading: Icon(spam ? Icons.warning : Icons.verified_user,
                    color: spam ? Colors.red : Colors.green),
                title: Text(result!),
                subtitle: Text(spam ? 'Reported as spam' : 'Looks safe'),
              ),
            ),
        ]),
      );
}

// ---------------- Menu ----------------
class MenuPage extends StatefulWidget {
  const MenuPage({super.key});
  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  bool popup = true;
  double textSize = 2;

  Widget item(IconData i, String t, {VoidCallback? onTap, String? sub}) =>
      ListTile(
        leading: CircleAvatar(backgroundColor: kSoft, child: Icon(i, color: kBlue)),
        title: Text(t),
        subtitle: sub == null ? null : Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Menu')),
        body: ListView(children: [
          const ListTile(
            leading: CircleAvatar(radius: 26, child: Icon(Icons.person)),
            title: Text('Your Name', style: TextStyle(fontSize: 20)),
            subtitle: Text('Free User'),
            trailing: Icon(Icons.chevron_right),
          ),
          ListTile(
            leading: const Icon(Icons.workspace_premium, color: Colors.orange),
            title: const Text('Get Premium – Nov Deal 50% Off!'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PremiumPage())),
          ),
          const Divider(),
          const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Caller ID',
                  style: TextStyle(fontSize: 22, color: kDark))),
          _radio('Full Screen Photos (requires default dialer)', !popup,
              () => setState(() => popup = false)),
          _radio('Popup', popup, () => setState(() => popup = true)),
          const Divider(),
          item(Icons.brush, 'Customize', sub: 'Light'),
          item(Icons.phone_callback, 'Call Ringing'),
          item(Icons.cloud_upload_outlined, 'Backup'),
          item(Icons.settings, 'Settings',
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()))),
          item(Icons.add_photo_alternate_outlined, 'New Photos for You'),
          item(Icons.card_giftcard, 'Invite for a free gift'),
          item(Icons.thumb_up_alt_outlined, 'Like us'),
          const Divider(),
          const ListTile(
              leading: Icon(Icons.text_fields, color: kBlue),
              title: Text('Text size')),
          Slider(
              value: textSize,
              min: 0,
              max: 4,
              divisions: 4,
              onChanged: (v) => setState(() => textSize = v)),
        ]),
      );

  Widget _radio(String t, bool sel, VoidCallback onTap) => ListTile(
        title: Text(t),
        trailing: Icon(sel ? Icons.radio_button_checked : Icons.radio_button_off,
            color: kBlue),
        onTap: onTap,
      );
}

// ---------------- Settings ----------------
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool fullScreen = true, sms = true, wa = true, tg = true, missed = true;

  Widget sw(IconData i, String t, bool v, ValueChanged<bool> f) => SwitchListTile(
        secondary: CircleAvatar(backgroundColor: kSoft, child: Icon(i, color: kBlue)),
        title: Text(t),
        value: v,
        onChanged: f,
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Settings')),
        body: ListView(children: [
          const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Aftercall Style',
                  style: TextStyle(fontSize: 22, color: kDark))),
          ListTile(
              title: const Text('Full screen'),
              trailing: Icon(
                  fullScreen ? Icons.radio_button_checked : Icons.radio_button_off,
                  color: kBlue),
              onTap: () => setState(() => fullScreen = true)),
          ListTile(
              title: const Text('Compact'),
              trailing: Icon(
                  !fullScreen ? Icons.radio_button_checked : Icons.radio_button_off,
                  color: kBlue),
              onTap: () => setState(() => fullScreen = false)),
          const Divider(),
          sw(Icons.sms_outlined, 'Show arrival SMS', sms, (v) => setState(() => sms = v)),
          sw(Icons.call, 'Show WhatsApp Caller ID', wa, (v) => setState(() => wa = v)),
          sw(Icons.send, 'Show Telegram Caller ID', tg, (v) => setState(() => tg = v)),
          sw(Icons.phone_missed, 'Show missed calls notification', missed,
              (v) => setState(() => missed = v)),
          const Divider(),
          const ListTile(
              leading: Icon(Icons.translate, color: kBlue),
              title: Text('Change Language'),
              subtitle: Text('English')),
          const ListTile(leading: Icon(Icons.sim_card, color: kBlue), title: Text('Dual SIM')),
          const ListTile(leading: Icon(Icons.block, color: Colors.red), title: Text('Block list')),
          const ListTile(leading: Icon(Icons.info_outline, color: kBlue), title: Text('About Us')),
          const ListTile(leading: Icon(Icons.forum_outlined, color: kBlue), title: Text('FAQ')),
          const ListTile(leading: Icon(Icons.mail_outline, color: kBlue), title: Text('Write to us')),
          const ListTile(
              leading: Icon(Icons.message_outlined, color: kBlue),
              title: Text('Message for incoming calls'),
              subtitle: Text('Can I call you later?')),
        ]),
      );
}

// ---------------- Premium ----------------
class PremiumPage extends StatefulWidget {
  const PremiumPage({super.key});
  @override
  State<PremiumPage> createState() => _PremiumPageState();
}

class _PremiumPageState extends State<PremiumPage> {
  int plan = 0;

  Widget planCard(int i, String title, String old, String price, {bool best = false}) =>
      GestureDetector(
        onTap: () => setState(() => plan = i),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
                color: plan == i ? Colors.orange : Colors.transparent, width: 3),
          ),
          child: Column(children: [
            if (best)
              const Align(
                  alignment: Alignment.centerLeft,
                  child: Chip(
                      label: Text('BEST VALUE'),
                      backgroundColor: Colors.orange)),
            Text(title,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: kDark)),
            Text.rich(TextSpan(children: [
              TextSpan(
                  text: '$old  ',
                  style: const TextStyle(
                      decoration: TextDecoration.lineThrough, color: Colors.grey)),
              TextSpan(text: price, style: const TextStyle(color: kDark)),
            ])),
            const Text('3 days free trial',
                style: TextStyle(color: Colors.orange, fontSize: 18)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF08101B),
        appBar: AppBar(
          backgroundColor: const Color(0xFF08101B),
          foregroundColor: Colors.white,
          title: const Text('Premium'),
        ),
        body: ListView(children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
                color: kBlue, borderRadius: BorderRadius.circular(16)),
            child: const Text('TRY PREMIUM\nFOR FREE\n\nFULL SPAM PROTECTION',
                style: TextStyle(
                    color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
          ),
          const Center(
              child: Text('Our plans',
                  style: TextStyle(color: Colors.white, fontSize: 24))),
          planCard(0, 'Yearly', 'BDT 449.00', 'BDT 224.50', best: true),
          planCard(1, 'Monthly', 'BDT 49.00', 'BDT 24.50'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            child: FilledButton(
                onPressed: () {},
                child: const Padding(
                    padding: EdgeInsets.all(12), child: Text('Start free trial'))),
          ),
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text(
                'After your free trial, you’ll pay according to your selected plan. Cancel anytime, for any reason.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70)),
          ),
        ]),
      );
}
