create table if not exists numbers (
  number text primary key,
  name text,
  spam_count int not null default 0,
  updated_at timestamptz not null default now()
);

alter table numbers enable row level security;

drop policy if exists "read numbers" on numbers;
create policy "read numbers" on numbers for select using (true);

create or replace function report_spam(p_number text) returns void
language plpgsql security definer as $$
begin
  insert into numbers(number, spam_count) values (p_number, 1)
  on conflict (number) do update
    set spam_count = numbers.spam_count + 1, updated_at = now();
end $$;

create or replace function suggest_name(p_number text, p_name text) returns void
language plpgsql security definer as $$
begin
  insert into numbers(number, name) values (p_number, left(p_name, 60))
  on conflict (number) do update
    set name = coalesce(numbers.name, left(p_name, 60)), updated_at = now();
end $$;

grant execute on function report_spam(text) to anon;
grant execute on function suggest_name(text, text) to anon;
