"""Run after `flutter create`. Adds permissions, incoming-call receiver,
overlay popup (Kotlin) and core library desugaring to the Android project."""
import glob
import json
import os
import re

MANIFEST = 'android/app/src/main/AndroidManifest.xml'

# ---------- find package from MainActivity ----------
main_act = glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True)[0]
pkg = re.search(r'^package\s+([\w.]+)', open(main_act).read(), re.M).group(1)
kt_dir = os.path.dirname(main_act)
print('package:', pkg)

# ---------- Kotlin receiver + overlay ----------
cfg = {}
if os.path.exists('config.json'):
    cfg = json.load(open('config.json'))
url = cfg.get('SUPABASE_URL', '').strip().rstrip('/')
key = cfg.get('SUPABASE_ANON_KEY', '').strip()
print('config: server set =', bool(url and key))
open('lib/config.dart', 'w').write(
    "class AppConfig {\n  static const url = '%s';\n  static const anonKey = '%s';\n"
    "  static bool get isSet => url.isNotEmpty && anonKey.isNotEmpty;\n}\n" % (url, key))

tmpl = (open('caller_id_app/tools/CallReceiver.kt.tmpl').read()
        .replace('__PKG__', pkg)
        .replace('__SUPABASE_URL__', url)
        .replace('__SUPABASE_KEY__', key))
open(os.path.join(kt_dir, 'CallReceiver.kt'), 'w').write(tmpl)

# ---------- Manifest ----------
s = open(MANIFEST).read()
perms = '''
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.READ_CALL_LOG"/>
    <uses-permission android:name="android.permission.READ_CONTACTS"/>
    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <queries>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="tel"/>
        </intent>
    </queries>
'''
i = s.index('>', s.index('<manifest')) + 1
s = s[:i] + perms + s[i:]

receiver = '''
        <receiver android:name="%s.CallReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.PHONE_STATE"/>
            </intent-filter>
        </receiver>
    ''' % pkg
j = s.rindex('</application>')
s = s[:j] + receiver + s[j:]
open(MANIFEST, 'w').write(s)

# ---------- Core library desugaring ----------
d = 'android/app/'
if os.path.exists(d + 'build.gradle.kts'):
    p = d + 'build.gradle.kts'
    g = open(p).read()
    g = g.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
    g += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
else:
    p = d + 'build.gradle'
    g = open(p).read()
    g = g.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
    g += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
open(p, 'w').write(g)
print('patched OK')
